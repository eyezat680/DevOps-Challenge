# DevOps-Challenge
This repo contains the source code used as part of the interview assessment for Platform (DevOps) Engineer role.

The application code itself has been sourced from https://github.com/laravel/laravel

For more information about the content about the challenge itself, please reach out to your hiring manager.

## Open positions

For more information about working for iPrice, please view our Careers page: https://ipricegroup.com/career.html
